var struct_sound =
[
    [ "this", "struct_sound.html#ae01ed9f9b5340847de9638215d3c1e4c", null ],
    [ "PlaySound", "struct_sound.html#a7f9c91aa25f50fb3276e7d4b4af5cac1", null ],
    [ "ResumeSound", "struct_sound.html#a0ba6acb18902530dab49e72c2f6c8bef", null ],
    [ "mAudioSpec", "struct_sound.html#a30a152e3b05487f831e6e9acce1ad491", null ],
    [ "mFilepath", "struct_sound.html#ad13d79b6c74577c514a7126080263d18", null ],
    [ "mID", "struct_sound.html#af87af45274757466a5715b1dc84550a1", null ],
    [ "mStream", "struct_sound.html#a335e5fe41b699da7d3bbea1e357cb2b4", null ],
    [ "mWaveData", "struct_sound.html#a4c2de681f7f15f78297544f1114c7d0f", null ],
    [ "mWaveDataLength", "struct_sound.html#a7668bfdef28b074492f82ab48a234bf5", null ]
];