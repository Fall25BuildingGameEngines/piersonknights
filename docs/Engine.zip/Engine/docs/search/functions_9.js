var searchData=
[
  ['normalize_0',['Normalize',['../vec2_8d.html#a14e9dc30887e422f032ef8306689ab97',1,'vec2.d']]]
];
