var searchData=
[
  ['textcomponent_0',['TextComponent',['../class_text_component.html',1,'']]]
];
