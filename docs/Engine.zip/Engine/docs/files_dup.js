var files_dup =
[
    [ "assets", "dir_34e9a5f624ac092a9ae2401c28d616d7.html", "dir_34e9a5f624ac092a9ae2401c28d616d7" ],
    [ "source", "dir_b2f33c71d4aa5e7af42a1ca61ff5af1b.html", "dir_b2f33c71d4aa5e7af42a1ca61ff5af1b" ]
];